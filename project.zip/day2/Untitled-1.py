# def fac(n):
#     mul=1
#     for i in range(1,n+1):
#         mul=mul*i
#     return mul
# n=int(input())
# print(fac(n))

# def pow(base,exponent):
#     n=base
#     m=exponent
#     return((n**m))
# base=int(input())
# exponent=int(input())
# print(pow(base,exponent))

# def prime(n):
#     for i in range(2,n):
#         if n%i==0:
#             return False
#     return True
# n=int(input())
# print(prime(n))

